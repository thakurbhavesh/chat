const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Middleware to serve static files
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true })); // For parsing URL-encoded data

// Temporary storage for users
let users = {}; // This will store usernames

// Serve the auth.html file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'auth.html')); // Show auth page
});

// User login endpoint
app.post('/login', (req, res) => {
    const { username } = req.body;

    if (users[username]) {
        return res.status(200).json({ message: 'Login successful', username });
    } else {
        return res.status(400).json({ message: 'User not found. Please register first.' });
    }
});

// User registration endpoint
app.post('/register', (req, res) => {
    const { username } = req.body;

    if (users[username]) {
        return res.status(400).json({ message: 'Username already exists' });
    }
    
    users[username] = true; // Add user to temporary storage
    res.status(201).json({ message: 'User registered successfully' });
});

// Socket.IO connection
io.on('connection', (socket) => {
    console.log('A user connected');

    // When a user joins, save their username
    socket.on('username', (username) => {
        socket.username = username; // Store the username in the socket object
        console.log(`${username} joined the chat`);
        socket.broadcast.emit('user joined', `${username} joined the chat`); // Notify others
    });

    // When a chat message is received
    socket.on('chat message', (msg) => {
        msg.time = new Date();
        io.emit('chat message', msg); // Broadcast message to all users
    });

    // Typing notification
    socket.on('typing', (username) => {
        socket.broadcast.emit('typing', username); // Notify others that a user is typing
    });

    // When a user disconnects
    socket.on('disconnect', () => {
        console.log(`${socket.username} left the chat`);
        socket.broadcast.emit('user left', `${socket.username} left the chat`); // Notify others
    });
});

// Start the server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
